import { useEffect } from "react";
import Footer from "./components/layout/Footer";
import Header from "./components/layout/Header";
import About from "./components/sections/About";
import CTA from "./components/sections/CTA";
import Clients from "./components/sections/Clients";
import Hero from "./components/sections/Hero";
import HowItWorks from "./components/sections/HowItWorks";
import Services from "./components/sections/Services";
import Testimonials from "./components/sections/Testimonials";

const pageContent = {
  "/protheus": {
    eyebrow: "TOTVS Protheus",
    title: "Consultoria para evoluir, integrar e sustentar o Protheus.",
    text: "Mapeamos processos, ajustamos rotinas, criamos integrações e apoiamos a operação para que o ERP acompanhe o crescimento da empresa.",
    items: ["Parametrização e sustentação", "Customizações ADVPL", "Integrações com APIs e sistemas externos"],
  },
  "/sistemas": {
    eyebrow: "Sistemas sob medida",
    title: "Software criado em cima do processo real da sua empresa.",
    text: "Desenvolvemos portais, dashboards, automações e aplicações web conectadas ao Protheus e aos sistemas que movem o negócio.",
    items: ["Portais operacionais", "Dashboards e BI", "Aplicações web integradas ao ERP"],
  },
  "/resultados": {
    eyebrow: "Resultados",
    title: "Projetos para operações que precisam de precisão.",
    text: "Ajudamos empresas a reduzir retrabalho, centralizar dados e transformar o Protheus em uma base mais conectada para decisão e execução.",
    items: ["Automação entre áreas", "Dados confiáveis para gestão", "Integração entre ERP, fiscal, vendas e logística"],
  },
  "/contato": {
    eyebrow: "Contato",
    title: "Vamos conversar sobre seu Protheus e seus sistemas.",
    text: "Conte onde a operação trava hoje. A partir disso, desenhamos um caminho claro para consultoria, integração ou desenvolvimento sob medida.",
    items: ["Diagnóstico inicial", "Plano técnico objetivo", "Próximos passos sem enrolação"],
  },
};

function App() {
  useEffect(() => {
    const animatedItems = document.querySelectorAll(".fade-up");
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.14 },
    );

    animatedItems.forEach((item) => observer.observe(item));
    return () => observer.disconnect();
  }, []);

  const path = window.location.pathname;
  const currentPage = pageContent[path];

  return (
    <>
      <Header />
      <main>
        {currentPage ? (
          <SimplePage page={currentPage} />
        ) : (
          <>
            <Hero />
            <About />
            <Services />
            <HowItWorks />
            <Clients />
            <Testimonials />
            <CTA />
          </>
        )}
      </main>
      <Footer />
    </>
  );
}

function SimplePage({ page }) {
  return (
    <section className="page-hero">
      <div className="container page-hero-inner fade-up">
        <span className="eyebrow">{page.eyebrow}</span>
        <h1>{page.title}</h1>
        <p>{page.text}</p>
        <div className="page-card-grid">
          {page.items.map((item) => (
            <article className="page-card" key={item}>
              <span></span>
              <h2>{item}</h2>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

export default App;
