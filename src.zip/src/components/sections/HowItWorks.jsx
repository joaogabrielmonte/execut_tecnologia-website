import Container from "../layout/Container";

const steps = [
  {
    num: "01",
    title: "Diagnóstico",
    text: "Mapeamos processos, sistemas e pontos de dor reais da operação antes de propor qualquer solução.",
  },
  {
    num: "02",
    title: "Plano técnico",
    text: "Desenhamos a arquitetura de integração e automação com prazo, escopo e entregáveis claros.",
  },
  {
    num: "03",
    title: "Desenvolvimento",
    text: "Implementamos no Protheus e nos sistemas conectados, com validações em cada etapa do projeto.",
  },
  {
    num: "04",
    title: "Operação contínua",
    text: "Sustentamos a solução, monitoramos indicadores e evoluímos conforme a empresa cresce.",
  },
];

function HowItWorks() {
  return (
    <section className="section section-edge" id="como-funciona">
      <Container>
        <div className="section-heading fade-up">
          <span className="eyebrow">Como funciona</span>
          <h2 className="section-title">Do diagnóstico ao resultado em 4 etapas.</h2>
          <p className="section-subtitle">
            Cada projeto começa com escuta e termina com uma solução que funciona na operação real —
            não só no papel.
          </p>
        </div>

        <div className="steps-grid">
          {steps.map((step) => (
            <div className="step fade-up" key={step.num}>
              <div className="step-num">{step.num}</div>
              <h4>{step.title}</h4>
              <p>{step.text}</p>
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
}

export default HowItWorks;