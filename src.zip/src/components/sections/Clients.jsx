import Container from "../layout/Container";

const clientLogos = [
  {
    name: "Grupo Locar",
    src: "/images/clients/grupo-locar.png",
    className: "client-logo-slot--locar",
  },
  {
    name: "Norcola",
    src: "/images/clients/norcola.png",
    className: "client-logo-slot--norcola",
  },
  {
    name: "Mavira Cloud",
    src: "/images/clients/mavira-cloud.svg",
    fictional: true,
  },
  {
    name: "Civora Labs",
    src: "/images/clients/civora-labs.svg",
    fictional: true,
  },
  {
    name: "Veltra Ops",
    src: "/images/clients/veltra-ops.svg",
    fictional: true,
  },
  {
    name: "Arqia Data",
    src: "/images/clients/arqia-data.svg",
    fictional: true,
  },
  {
    name: "Lumera Pay",
    src: "/images/clients/lumera-pay.svg",
    fictional: true,
  },
  {
    name: "Nordic Supply",
    src: "/images/clients/nordic-supply.svg",
    fictional: true,
  },
];

function Clients() {
  return (
    <section className="clients-section" id="clientes">
      <Container>
        <div className="clients-heading fade-up">
          <span className="eyebrow">Clientes</span>
          <h2>Empresas que confiam na Execut</h2>
        </div>

        <div className="logo-wall" aria-label="Logos de clientes e marcas ilustrativas">
          {clientLogos.map((logo) => (
            <div className={`client-logo-slot ${logo.className ?? ""}`} key={logo.name}>
              <img
                className="client-logo-image"
                src={logo.src}
                alt={`${logo.fictional ? "Marca ilustrativa" : "Logo"} ${logo.name}`}
                loading="lazy"
              />
            </div>
          ))}
        </div>
      </Container>
    </section>
  );
}

export default Clients;
