import Container from "../layout/Container";

const testimonials = [
  {
    quote:
      "A Execut trouxe mais organização, velocidade e confiança para nossos processos internos com uma entrega muito acima do esperado.",
    initials: "AM",
    name: "Ana Martins",
    role: "Diretora Operacional, Grupo Alfa",
  },
  {
    quote:
      "O time entendeu rapidamente nosso cenário e propôs uma solução moderna, objetiva e escalável para o negócio.",
    initials: "RC",
    name: "Rafael Costa",
    role: "Gerente de TI, Nova Gestão",
  },
  {
    quote:
      "Profissionalismo, clareza técnica e excelente comunicação em todas as etapas do projeto. Foi uma parceria muito sólida.",
    initials: "LS",
    name: "Larissa Souza",
    role: "CEO, Connect Business",
  },
];

function Testimonials() {
  return (
    <section className="section section-edge" id="depoimentos">
      <Container>
        <div className="section-heading fade-up">
          <span className="eyebrow">Depoimentos</span>
          <h2 className="section-title">
            Resultados que geram relacionamento de longo prazo.
          </h2>
        </div>

        <div className="testimonials-grid">
          {testimonials.map((testimonial) => (
            <article className="testimonial-card fade-up" key={testimonial.name}>
              <p>{testimonial.quote}</p>
              <div className="testimonial-person">
                <div className="avatar">{testimonial.initials}</div>
                <div>
                  <strong>{testimonial.name}</strong>
                  <span>{testimonial.role}</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </Container>
    </section>
  );
}

export default Testimonials;